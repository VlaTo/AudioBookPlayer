﻿using Xamarin.Forms;

namespace LibraProgramming.Xamarin.Interactivity
{
    public interface IRequestTrigger
    {

    }
}
