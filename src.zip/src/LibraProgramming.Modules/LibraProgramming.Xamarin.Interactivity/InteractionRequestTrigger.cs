﻿using Xamarin.Forms;

namespace LibraProgramming.Xamarin.Interactivity
{
    [ContentProperty(nameof(Actions))]
    public sealed class InteractionRequestTrigger : RequestTrigger
    {
    }
}
