﻿namespace LibraProgramming.Xamarin.Core
{
    public interface IPlatformDatabasePath
    {
        string GetDatabasePath(string databaseName);
    }
}