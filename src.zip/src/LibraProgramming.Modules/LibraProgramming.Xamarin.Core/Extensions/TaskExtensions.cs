﻿using System.Threading.Tasks;

namespace LibraProgramming.Xamarin.Core.Extensions
{
    internal static class TaskExtensions
    {
        public static void FireAndForget(this Task task)
        {
            ;
        }
    }
}