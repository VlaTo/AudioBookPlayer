﻿namespace LibraProgramming.Xamarin.Core.Extensions
{
    internal static class WeakEventManagerExtensions
	{
		/// <summary>
		/// Invokes the event EventHandler
		/// </summary>
		/// <param name="sender">Sender</param>
		/// <param name="eventArgs">Event arguments</param>
		/// <param name="eventName">Event name</param>
		/*public static void RaiseEvent<TEventArgs>(
			this WeakEventManager<TEventArgs> weakEventManager,
			object sender,
			TEventArgs eventArgs,
			string eventName)
			=> weakEventManager.HandleEvent(sender, eventArgs, eventName);*/
	}
}
