﻿using System;

namespace LibraProgramming.Xamarin.Interaction
{
    public static class Callback
    {
        public static readonly Action Empty = () => { };
    }
}
