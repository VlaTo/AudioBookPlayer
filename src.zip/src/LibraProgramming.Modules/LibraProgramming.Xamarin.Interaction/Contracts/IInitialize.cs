﻿namespace LibraProgramming.Xamarin.Interaction.Contracts
{
    public interface IInitialize
    {
        void OnInitialize();
    }
}
