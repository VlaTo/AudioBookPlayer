﻿namespace LibraProgramming.Xamarin.Interaction.Contracts
{
    public interface IDestructible
    {
        void OnDestroy();
    }
}
