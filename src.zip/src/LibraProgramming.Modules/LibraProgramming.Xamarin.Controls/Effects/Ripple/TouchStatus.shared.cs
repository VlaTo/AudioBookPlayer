﻿namespace LibraProgramming.Xamarin.Controls.Effects.Ripple
{
    /// <summary>
    /// 
    /// </summary>
    public enum TouchStatus
    {
        /// <summary>
        /// 
        /// </summary>
        Started,

        /// <summary>
        /// 
        /// </summary>
        Completed,

        /// <summary>
        /// 
        /// </summary>
        Canceled
    }
}