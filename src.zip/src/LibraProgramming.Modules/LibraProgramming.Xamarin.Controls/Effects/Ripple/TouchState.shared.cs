﻿namespace LibraProgramming.Xamarin.Controls.Effects.Ripple
{
    /// <summary>
    /// 
    /// </summary>
    public enum TouchState
    {
        /// <summary>
        /// 
        /// </summary>
        Normal,

        /// <summary>
        /// 
        /// </summary>
        Pressed
    }
}