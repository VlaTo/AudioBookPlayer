﻿namespace AudioBookPlayer.App.Core
{
    internal static class Routes
    {
        public const string PlayerPageRoute = "Player";
    }
}